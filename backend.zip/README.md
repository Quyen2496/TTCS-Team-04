# TTCS Team 04 - T2 Quang - Backend Check-in tích hợp giao diện

Frontend gốc được giữ trong `public/`; JavaScript đã nối với API backend. Backend phụ trách module `reception`.

## Chạy
1. Cài Node.js và MongoDB.
2. `npm install`
3. Sao chép `.env.example` thành `.env` và chỉnh `MONGODB_URI` nếu cần.
4. `npm start`
5. Mở `http://127.0.0.1:3000`

## API
- `POST /api/reception/checkins`
- `GET /api/reception/checkins`
- `GET /api/reception/checkins/:id`
- `PATCH /api/reception/checkins/:id/checkin`
- `PATCH /api/reception/checkins/:id/checkout`
- `PATCH /api/reception/checkins/:id/cancel`

## Git branch
`feature/t2-quang-checkin-api`
